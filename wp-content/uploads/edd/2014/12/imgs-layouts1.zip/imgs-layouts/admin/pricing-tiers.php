<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pricing Tiers</title>
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="css/ui.spinner.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.1/jquery.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/ui.spinner.js"></script>
	<script type="text/javascript">
		jQuery().ready(function($) {
			$(".spinnernull12").spinner({min: 0, max: 100, increment: 2});
		});
	</script>
</head>
<body>
<div id="main-wrapper">
<div class="full-width">
<div class="left-sidebar">
  <div class="logo"><a href="index.html"><img src="images/logo.png" alt="" /> </a></div>
  <div class="dashboard_2"><a href="index.html">Dashboard</a> </div>
  <div class="management" id="active_dashboard" ><a href="user-management.html">User Management</a> </div>
  <div class="commerce"><a href="store.html">Store</a> </div>
  <div class="messeges"><a href="new_messages.html">User Messaging</a> </div>  
  <div class="ticket"><a href="support-tickets.html">Ticket</a> </div>
  <div class="reports" ><a href="report.html">Reports</a> </div>
  <div class="oders"><a href="view-all-orders.html">Orders</a> </div>
  <div  class="quote_management"><a href="quote.html"> Quote Management</a></div>
  <div class="setting"><a href="setting.html"> Setting</a></div>
</div>
<!-- end left side bar -->
<div class="right-sidebar">
<div class="top-header">
  <form>
    <input class="search" type="text" value="Search" /><!--onblur="this.value=!this.value?'Search':this.value;" onfocus="this.select()" onclick="this.value='';" name="field-name-here"-->
    <select class="info-account">
      <option value="account">Account Info</option>
    </select>
  </form>
</div>
<!-- end top-header-->
<div class="navigation">
	<ul>
		<li class="top-icons"><a class="user_mgnt_1" href="create-a-dealer.html" >Create a Dealer</a></li>
		<li class="top-icons"><a class="user_mgnt_2" href="dealer.html" >View All Dealers</a></li>
		<li class="top-icons"><a class="user_mgnt_3" href="dealer-permissions.html" >Dealer Permissions</a></li>
		<li class="top-icons"><a class="user_mgnt_4" id="active_user_mgnt_4" href="pricing-tiers.php">Pricing Tiers</a></li>
		<li class="top-icons"><a class="user_mgnt_5" href="create-admin.html">Create an Admin</a></li>
		<li class="top-icons"><a class="user_mgnt_6"  href="view-all-admin.html" >View All Admins</a></li>
		<li class="top-icons"><a class="user_mgnt_7" href="admin-permissions.html" >Admin Permissions</a></li>
					
	</ul>
</div>
<div class="page_heading"><h1>Pricing Tiers</h1></div>
<div class="pricing_tires_table"> 
	<div class="dealer_table">
				<table cellspacing="0" cellpadding="0" border="0">
					<tbody><tr>
						<th style="border-left: 1px solid #c9c9c9">Tier Name</th>
						<th>View / Edit</th>
						
					</tr><tr>
					</tr><tr>
						<td class="active_acount">Tiers 1</td>
						<td class="active_acount"><a href="#"><img src="images/view_icon.png"></a> &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
						<a href="#"><img src="images/icon_edit.png"></a></td>
						
					</tr>
					<tr>
						<td class="deactive_acount">Tiers 2</td>
						<td class="deactive_acount"><a href="#"><img src="images/view_icon.png"></a> &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
						<a href="#"><img src="images/icon_edit.png"></a></td>
						
					</tr>
					<tr>
						<td class="active_acount">Tiers 3</td>
						<td class="active_acount"><a href="#"><img src="images/view_icon.png"></a> &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
						<a href="#"><img src="images/icon_edit.png"></a></td>
						
					</tr>
					<tr>
						<td class="deactive_acount">Tiers 2</td>
						<td class="deactive_acount"><a href="#"><img src="images/view_icon.png"></a> &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
						<a href="#"><img src="images/icon_edit.png"></a></td>
						
					</tr>
				</tbody>
				</table>
					<div class="export_cv"> <a href="#"> Save Changes </a></div>
			</div>
  
</div>
<div class="active_user2" id="tier_from"> 
  <div align="center">
    <form id="contact-info" class="pricing_tires_select">
	
      <fieldset>
        <div>
          <label class="name">Tier Name</label>
          <input type="text" value="">
        </div> 
			<div>
			 <label class="name">Apply to All</label>
			  <input type="text" class="spinnernull12"  name="apply" value="0" />	 
			</div> 
			<div>
			 <label class="name">Collection 1</label>
			  <input type="text" class="spinnernull12"  name="collection_1" value="0" />		  
			</div> 		  
			
			<div>
			 <label class="name">Collection 2</label>
			<input type="text" class="spinnernull12" name="collection_2" value="0" />		  
			</div> 
			<div>
			 <label class="name">Collection 3</label>
			<input type="text" class="spinnernull12"  name="collection_3" value="0" />	
			<div>
			 <label class="name">Collection 4</label>
			<input type="text" class="spinnernull12"  name="collection_4" value="0" />		  
			</div> 
			<div>
			 <label class="name">Collection 5</label>
			 <input type="text" class="spinnernull12"  name="collection_5" value="0" />			  
			</div> 
			<div>
			 <label class="name">Product 1</label>
			<input type="text" class="spinnernull12"  name="product_1" value="0" />			  
			</div> 
			<div>
			 <label class="name">Product 2</label>
			<input type="text" class="spinnernull12"  name="product_2" value="0" />			  
			</div> 
			<div>
			 <label class="name">Product 3</label>
			 <input type="text" class="spinnernull12"  name="product_3" value="0" />		  
			</div>
     
     
		<div class="dealer_btn">
		  <input name="submit" type="submit" value="Add New" class="add-dealer" />
		</div>
			   
      </fieldset>
    </form>
  </div>
</div>
<div style="clear:both;"></div>

</div>
<!--- end right side bar--->
</div>
<!-- end full width div-->
</div>
<!-- end main div--->
<div class="copy_wright">&copy; 2012. All Rights Reserved - IMGS</div>
</body>
</html>
