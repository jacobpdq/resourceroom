
This module can compress any files attached to a node and provides a 
download link. To use this module you have to extract the PclZip 
library in /sites/all/libraries/pclzip which can be downloaded 
here: http://www.phpconcept.net/pclzip/pclzip-downloads

This module is sponsored by www.Linalis.com

Installation 
------------

Place the download folder in the modules directory of your site and
enable it on the `admin/modules` page.
